
package pascaltoc.lexer;


public enum Keyword {
    
}
