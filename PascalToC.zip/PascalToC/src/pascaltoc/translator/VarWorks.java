
package pascaltoc.translator;


public class VarWorks {
    
}
