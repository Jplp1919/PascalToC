package pascaltoc.parser;


public class IncorrectGrammarException extends RuntimeException{

    public IncorrectGrammarException(String message) {
        super(message);
    }
    
}
