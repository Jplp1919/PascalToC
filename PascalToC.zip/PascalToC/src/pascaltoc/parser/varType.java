
package pascaltoc.parser;


enum varType {
    Character, Integer, Real, Boolean, String
}
